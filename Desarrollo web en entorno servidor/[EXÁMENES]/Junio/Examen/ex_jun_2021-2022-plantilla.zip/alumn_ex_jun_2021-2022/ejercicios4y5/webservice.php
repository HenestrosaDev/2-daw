<?php

//Almacena en un array dos instancias de la clase libro con los datos siguientes:
// ID=1 Título="PHP and MySQL Web Development (Developer's Library)" Autor/a="Laura Thompson" Precio=46.65
// ID=2 Título="Cocina de Resistencia" Autor/a="Alberto Chicote" Precio=20.80


//En función de la petición POST O GET, se realiza una cosa u otra.

