<?php

//Implementa aquí el apartado b) del ejercicio 2