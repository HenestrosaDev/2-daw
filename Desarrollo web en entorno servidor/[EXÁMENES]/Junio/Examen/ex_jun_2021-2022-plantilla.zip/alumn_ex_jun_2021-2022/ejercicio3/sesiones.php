<?php

// Implementar aquí el ejercicio 3

//Puedes usar los siguientes formularios para ayudarte
?>

<form action="sesiones.php" method="post">
    <label for="precio">Introduce el título:</label><input type="text" name="titulo" id="titulo"><br>
    <input type="submit" value="enviar">
</form>

<form action="sesiones.php" method="post">
    <label for="precio">Introduce el precio:</label><input type="text" name="precio" id="precio"><br>
    <input type="submit" value="enviar">
</form>
