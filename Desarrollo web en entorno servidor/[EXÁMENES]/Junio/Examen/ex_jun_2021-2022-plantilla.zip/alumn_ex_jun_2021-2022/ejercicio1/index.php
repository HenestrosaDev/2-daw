<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Libros</title>
        <link rel="stylesheet" type="text/css" href="estilos.css" media="screen" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>
    <body>
        <?php
        // incluir aquí el fichero funciones.php
        

        // Declaración del array ASOCIATIVO, se proporcionan los datos
        /*
          1   PHP and MySQL Web Development (Developer's Library)         Laura Thompson  46.65
          2   Cocina de Resistencia                                       Alberto Chicote 20.80
          3   El dragón rojo                                              Thomas Harris   9.45
          4   Pilotos legendarios de la fórmula 1 (Retratos legendarios)  Xavier Chimits  25
         */
        

        // Mostrar el listado de todos los libros
        

        // Ordenar y Mostrar el listado de libros ordenado según el orden solicitado
        // al enviar el formulario


        /* Formulario para ordenar y mostrar los libros
         * 
         */
        echo '<form name="" action="" method="">';
        echo '<br/>';
        echo '<input name="" type="" value = ""> Título';
        echo '<input name="" type="" value = ""> Autor';
        echo '<input name="" type="" value = ""> ^Precio';
        echo ' <input name="" title="" type="" value="">';

        echo '</form>';
        ?>
    </body>
</html>