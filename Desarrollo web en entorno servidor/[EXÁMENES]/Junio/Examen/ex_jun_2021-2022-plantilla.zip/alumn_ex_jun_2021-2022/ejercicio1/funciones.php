<?php

function mostrarLibros( /* parametros */ ) {
    
}

function ordenar( /* parametros */ ) {
    
    // crea un array auxiliar con los datos del campo elegido
    
    
    // ejecuta la función de ordenación
    
            
    // devuelve el array ordenado
    
}